package game.assets

import game.assets.gameengine._
import scalafxml.core.{FXMLLoader, FXMLView, NoDependencyResolver}
import scalafx.animation.AnimationTimer
import scalafx.application.JFXApp
import scalafx.scene.{Group, Scene}
import scalafx.scene.control.Alert
import scalafx.scene.control.Alert.AlertType
import scalafx.scene.layout.StackPane
import scalafx.Includes._
import javafx.{scene => jfxs}
import scalafx.scene.media.{Media, MediaPlayer}
import scalafx.scene.paint.Color
import scalafx.scene.transform.Translate

object MainApp extends JFXApp {

  val welcome = new Media(getClass.getResource("/game.assets/view/Welcome.mp3").toString)
  val welcomePlayer = new MediaPlayer(welcome) {
    cycleCount = MediaPlayer.Indefinite
  }
  val ambience = new Media(getClass.getResource("/game.assets/view/ambience.mp3").toString)
  val ambiencePlayer = new MediaPlayer(ambience) {
    cycleCount = MediaPlayer.Indefinite
  }


  stage = new JFXApp.PrimaryStage {
    width = 1050
    height = 750
    title = "Tile Game"
    resizable = false


  }

  val scene = new Scene(){
    fill = Color.Black

  }
  stage.scene = scene


  def startGame(): Unit = {
    welcomePlayer.stop()
    ambiencePlayer.stop()

    val base = new GamePane(40, 30, 50, 1, 1, 50)

    base.ghostImg.fitWidth <== stage.scene.width
    base.ghostImg.fitHeight <== stage.scene.height
    base.youLose.fitWidth <== stage.scene.width
    base.youLose.fitHeight <== stage.scene.height


    val viewport = new StackPane(
    )
    viewport.children.addAll(base.grid)

    viewport.layoutX.onChange((_, _, x) => {
      println(x)
    })

    // Create translation transforms
    val translateX = new Translate()
    val translateY = new Translate()

    // Bind the translation transforms to camera layout properties
    translateX.xProperty().bind(base.cameraLayoutX)
    translateY.yProperty().bind(base.cameraLayoutY)

    // Apply translation transforms to the viewport's transforms
    viewport.getTransforms.addAll(translateX, translateY)
    this.scene.content =  new Group(viewport, base.ghostImg, base.blackoutRectangle, base.ghostAvatar, base.youLose)
    def update(elapsedTime: Double): Unit = {

      base.ghostAvatar.requestFocus()
      viewport.children(0).requestFocus()
      base.ghostImg.requestFocus()
      base.youLose.requestFocus()
      base.blackoutRectangle.requestFocus()


    }

    // to call, gameLoop.Loop.start()
    var lastUpdateTime: Long = 0
    val gameLoop = AnimationTimer { currentTime =>
      if (lastUpdateTime == 0) {
        lastUpdateTime = currentTime
      }

      val elapsedTime = (currentTime - lastUpdateTime).toDouble / 1e9
      update(elapsedTime)
      lastUpdateTime = currentTime
    }

    gameLoop.start()
//    || base.colDetect.isGhost(base.Player.X, base.Player.Y
    if(base.isExit  ){

      gameLoop.stop
    }
}

//


def showWelcome() = {
  ambiencePlayer.stop()
  welcomePlayer.play()

  val resource = getClass.getResource("/game.assets/view/Welcome.fxml")
  val loader = new FXMLLoader(resource, NoDependencyResolver)
  loader.load();
  val roots = loader.getRoot[jfxs.layout.AnchorPane]() //1 app can have more than 1 view
  this.scene.content = roots

}

  showWelcome()
  //startGame()

  def showStory() = {
    welcomePlayer.stop()
    ambiencePlayer.play()

    val resource = getClass.getResource("/game.assets/view/Story.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots = loader.getRoot[jfxs.layout.AnchorPane]() //1 app can have more than 1 view
    this.scene.content = roots

  }

  def showTutorial() = {


    val resource = getClass.getResource("/game.assets/view/Tutorial.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots = loader.getRoot[jfxs.layout.AnchorPane]() //1 app can have more than 1 view
    this.scene.content = roots

  }

  def showLose() = {


    val resource = getClass.getResource("/game.assets/view/Lose.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots = loader.getRoot[jfxs.layout.AnchorPane]() //1 app can have more than 1 view
    this.scene.content = roots

  }

  def showWin() = {
  ambiencePlayer.play()

    val resource = getClass.getResource("/game.assets/view/Win.fxml")
    val loader = new FXMLLoader(resource, NoDependencyResolver)
    loader.load();
    val roots = loader.getRoot[jfxs.layout.AnchorPane]() //1 app can have more than 1 view
    this.scene.content = roots

  }
  def showAlert(title: String, content: String): Unit = {
    val alert = new Alert(AlertType.Information) {
      initOwner(stage)
      title = title.toString()
      headerText = None
      contentText = content
    }
    alert.showAndWait()
  }


//  blackGrid2.opacity <== base.Player.imageView.yProperty().multiply(-0.1).add(1.0)
}