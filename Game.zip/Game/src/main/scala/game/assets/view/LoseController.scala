package game.assets.view

import game.assets.MainApp
import scalafxml.core.macros.sfxml


@sfxml
class LoseController {



  def start(): Unit = {

    MainApp.showWelcome()

  }


}
