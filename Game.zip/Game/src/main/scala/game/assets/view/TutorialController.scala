package game.assets.view

import game.assets.MainApp
import scalafxml.core.macros.sfxml

@sfxml
class TutorialController {

  def start(): Unit = {
  MainApp.startGame()
  }

}
