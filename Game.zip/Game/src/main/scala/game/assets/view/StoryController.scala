package game.assets.view

import game.assets.MainApp
import scalafxml.core.macros.sfxml

@sfxml
class StoryController {

  def tutorial(): Unit = {
  MainApp.showTutorial()
  }

}
