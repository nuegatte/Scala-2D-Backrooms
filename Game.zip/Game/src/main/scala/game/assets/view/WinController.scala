package game.assets.view

import game.assets.MainApp
import scalafxml.core.macros.sfxml

@sfxml
class WinController {

  def start(): Unit = {

    MainApp.showWelcome()

  }

}
