package game.assets.gameengine

import scala.util.Random

abstract class EnvironmentObject(gridWidth : Int, gridHeight: Int){

  type coordinate = (Int, Int)

  val random = new Random
  var coordinates = Set.empty[coordinate]

  //     Function to calcualte distance between ghost coordinates
  def distance(coord1: coordinate, coord2: coordinate): Double = {
    val dx = coord1._1 - coord2._1
    val dy = coord1._2 - coord2._2
    math.sqrt(dx * dx + dy * dy)
  }

  def generate(num: Int) : Set[coordinate]


}