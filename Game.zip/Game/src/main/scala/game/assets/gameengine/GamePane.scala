package game.assets.gameengine

import game.assets.MainApp
import scalafx.application.Platform
import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.input.{KeyCode, KeyEvent}
import scalafx.scene.layout.{GridPane, StackPane}
import scalafx.scene.paint.Color
import scalafx.scene.shape.Rectangle
import scalafx.Includes._
import scalafx.animation.{KeyFrame, Timeline}
import scalafx.beans.property.DoubleProperty
import scalafx.event
import scalafx.scene.media.{Media, MediaPlayer}
import scalafx.util.Duration

import scala.util.Random



class GamePane(Width : Int, Height: Int, Size: Int, spawnX: Int, spawnY: Int , ghostCount : Int)extends GridPane {

  val gridWidth: Int = Width
  val gridHeight: Int = Height
  val viewableSizeX = 21
  val viewableSizeY = 15
  val tileSize: Int = Size

  val Player = new Player(spawnX, spawnY, tileSize)

  private val walls = new Walls(Player.X, Player.Y, gridWidth, gridHeight)
  private val wallsSet = walls.generate((gridWidth* gridHeight *0.2).toInt)
  private val Ghost = new Ghost(gridWidth, gridHeight, spawnX, spawnY, wallsSet )
  private val ghosts = Ghost.generate(ghostCount)
  private val ghostAura = Ghost.generateAura(ghosts)

  val ghostImg = Ghost.ghostImgView
  val ghostWarning = Ghost.ghostWarning
  val ghostAvatar = Ghost.ghostAvatarImg
  val youLose = Ghost.youLoseImg
  ghostAvatar.fitWidth = tileSize
  ghostAvatar.fitHeight = tileSize


  val doorOpen = new Media(getClass.getResource("/game.assets/exit/doorOpen.mp3").toString)
  val doorPlayer = new MediaPlayer(doorOpen)

  val colDetect = new CollisionDetection(ghosts, ghostAura, wallsSet , gridWidth, gridHeight)


  val cameraLayoutX = DoubleProperty((Player.X - viewableSizeX / 2) * tileSize * -1)
  val cameraLayoutY = DoubleProperty((Player.Y - viewableSizeY / 2) * tileSize * -1)

  def calculateOpacity(playerX: Int, playerY: Int, cellX: Int, cellY: Int): Double = {
    val distance = math.sqrt((playerX - cellX) * (playerX - cellX) + (playerY - cellY) * (playerY - cellY))
    val minDistance = 1
    val maxDistance = 5
    val minOpacity = 0.3
    val maxOpacity = 1.0
    val normalizedDistance = (distance - minDistance) / (maxDistance - minDistance)
    val opacity = math.max(minOpacity, math.min(maxOpacity, minOpacity + normalizedDistance * (maxOpacity - minOpacity)))
    opacity
  }

  def generateExit(ghosts: Set[(Int, Int)], wallsSet: Set[(Int, Int)]): (Int, Int) = {
    var exitX = 0
    var exitY = 0
    val random = new Random()

    var exitCoordinatesFound = false
    while (!exitCoordinatesFound) {
      exitX = random.nextInt(gridWidth)
      exitY = random.nextInt(gridHeight)
      val minDistanceToGhosts = 2.0
      val minDistanceToWalls = 2.0

      val distanceToGhosts = ghosts.forall(existingCoord => Ghost.distance((exitX, exitY), existingCoord) >= minDistanceToGhosts)
      val distanceToWalls = wallsSet.forall(wallCoord => walls.distance((exitX, exitY), wallCoord) >= minDistanceToWalls)

      if (distanceToGhosts && distanceToWalls) {
        exitCoordinatesFound = true
      }
    }

    (exitX, exitY)
  }

  val exitCoord = generateExit(ghosts,wallsSet)
  val Exit = Set(exitCoord)



  val gridCells = Array.ofDim[Rectangle](gridWidth, gridHeight)

  val blackoutRectangle = new Rectangle {
    width = viewableSizeX * tileSize
    height = viewableSizeY * tileSize
    fill = Color.Black
    visible = false
  }

  def updateGridOpacity(): Unit = {
    for (i <- 0 until gridWidth; j <- 0 until gridHeight) {
      gridCells(i)(j).opacity = calculateOpacity(Player.X, Player.Y, i, j)
    }
  }
  val grid = new GridPane()


  for (i <- 0 until gridWidth; j <- 0 until gridHeight) {
    val rect = new Rectangle {
      width = tileSize
      height = tileSize
      fill = Color.SandyBrown

      opacity = 0.4 + (0.5 - 0.35) * Random.nextDouble()
    }
    grid.add(rect, i, j)
  }



  for ((x, y) <- ghosts) {
    val rect = new Rectangle{
      width = tileSize
      height = tileSize
      fill = Color.Transparent
    }

    grid.add(rect, x, y)
  }

  val exitDoor = new Image(getClass.getResource("/game.assets/exit/exitDoor.png").toString)
  val exitDoorImg = new ImageView(exitDoor)
  exitDoorImg.fitWidth = tileSize
  exitDoorImg.fitHeight = tileSize
  grid.add(exitDoorImg, exitCoord._1, exitCoord._2)


  for ((x, y) <- ghostAura) {
    val auraRect = new Rectangle {
      width = tileSize
      height = tileSize
      fill = Color.Transparent

    }
    grid.add(auraRect, x, y)
  }
  grid.add(Player.imageView, Player.X, Player.Y)



  //    for ((x, y, length, orientation) <- walls) {
  for ((x, y) <- wallsSet) {

    val wallRect = new Rectangle {
      width = tileSize
      height = tileSize
      //        stroke = Color.Yellow.opacity(0.6)
      fill = Color.Khaki
    }
    grid.add(wallRect, x, y)
  }




  for (i <- 0 until gridWidth; j <- 0 until gridHeight) {
    val rect = new Rectangle {
      width = tileSize
      height = tileSize
      fill = Color.Black
      opacity = calculateOpacity(Player.X, Player.Y, i, j) // Update opacity here
    }
    gridCells(i)(j) = rect
    grid.add(rect, i, j)
  }


  var isExit = false

  val loseTimeline = new Timeline {
    keyFrames = Seq(
      KeyFrame(Duration(600.00), onFinished = _ => {
        // showAlert("Interaction", "You interacted with the red square!")
        youLose.visible = true
        Ghost.losePlayer.play()
 //replace with scray audio and jumpscare
        val movingOn = new Timeline {
          keyFrames = Seq(
            KeyFrame(Duration(4000), onFinished = _ => {
              youLose.visible = false
              isExit = false
              MainApp.showLose() //replace with showLose



            })
          )
        }
        movingOn.play()
      })
    )
  }

  val winTimeline = new Timeline {
    keyFrames = Seq(
      KeyFrame(Duration(3700.00), onFinished = _ => {
        // showAlert("Interaction", "You interacted with the red square!")
        blackoutRectangle.visible = true
        val movingOn = new Timeline {
          keyFrames = Seq(
            KeyFrame(Duration(2000), onFinished = _ => {

              isExit = false
              MainApp.showWin() //replace with showWin
              blackoutRectangle.visible = false


            })
          )
        }
        movingOn.play()
      })
    )
  }

  def movePlayer(dx: Int, dy: Int, gridPane: GridPane, img: Image): Unit = {
    val newX = Player.X + dx
    val newY = Player.Y + dy

    if (colDetect.isValidMove(newX, newY) && !colDetect.isCollision(newX, newY)) {
      Player.X = newX
      Player.Y = newY
      cameraLayoutX.value = (Player.X - viewableSizeX / 2) * tileSize * -1
      cameraLayoutY.value = (Player.Y - viewableSizeY / 2) * tileSize * -1

      println(newX, newY)
      Platform.runLater {
        Player.footstepPlayer.stop()
        Player.footstepPlayer.play()
        GridPane.setColumnIndex(Player.imageView, Player.X)
        GridPane.setRowIndex(Player.imageView, Player.Y)
        Player.imageView.image = img
      }
    } else {
      Player.collidePlayer.stop()
      Player.collidePlayer.play()
      println("Stop Hitting yourself.")
      Player.imageView.image = img
    }

    if (colDetect.isGhost(newX, newY)) {
      isExit = true
      Ghost.hissPlayer.play()
      grid.add(ghostAvatar, newX, newY)
      loseTimeline.play()




      //      stage.close()

    }


    if (colDetect.isAura(newX, newY)) {
      Player.X = newX
      Player.Y = newY
      println("I sense something uneasy...")
      Platform.runLater {
        //
        Ghost.auraPlayer.stop()
        Ghost.auraPlayer.play()
        Ghost.ghostWarning.stop()
        Ghost.ghostWarning.play()
        GridPane.setColumnIndex(Player.imageView, Player.X)
        GridPane.setRowIndex(Player.imageView, Player.Y)
        Player.imageView.image = img
      }
    }
  }


  def handleKeyPress(e: KeyEvent): Unit = {
    println("..............\n" + "Key pressed: " + e.code)
    e.code match {
      case KeyCode.W | KeyCode.Up =>
        if (!isExit) {
          movePlayer(0, -1, grid, Player.playerUp)
          updateGridOpacity()
        }
      case KeyCode.A | KeyCode.Left =>
        if (!isExit) {
          movePlayer(-1, 0, grid, Player.playerLeft)
          updateGridOpacity()
        }
      case KeyCode.S | KeyCode.Down =>
        if (!isExit) {
          movePlayer(0, 1, grid, Player.playerDefault)
          updateGridOpacity()
        }
      case KeyCode.D | KeyCode.Right =>
        if (!isExit) {
          movePlayer(1, 0, grid, Player.playerRight)
          updateGridOpacity()
        }
      case KeyCode.R =>
        MainApp.startGame() // test if the game reset is working as intended
      case KeyCode.Enter =>

        if (Player.X == exitCoord._1 && Player.Y == exitCoord._2) {
          isExit = true
          e.consume()
          doorPlayer.play()

          // Create a Timeline with a delay of 3 seconds

          winTimeline.play()

        }

      case _ =>
    }
  }


    grid.onKeyPressed = handleKeyPress _












}