package game.assets.gameengine


import scalafx.animation.{KeyFrame, Timeline}
import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.media.{Media, MediaPlayer}
import scalafx.util.Duration



class Ghost(gridWidth : Int, gridHeight: Int, playerX: Int, playerY : Int, wallsSet: Set[(Int, Int)] )extends EnvironmentObject(gridWidth : Int, gridHeight: Int) {


  val displayTime = 40
  val ghostImg = new Image(getClass.getResourceAsStream("/game.assets/ghost/ghost.jpg"))

  val ghostImgView = new ImageView(ghostImg)
  ghostImgView.visible = false
  val ghostWarning = new Timeline {
    keyFrames = Seq(
      KeyFrame(Duration.Zero, onFinished = _ => ghostImgView.visible = true), // Show image view
      KeyFrame(Duration(displayTime), onFinished = _ => ghostImgView.visible = false), // Hide image view

    )
  }

  val ghostAvatar = new Image(getClass.getResourceAsStream("/game.assets/ghost/ghostAvatar.png"))
  val ghostAvatarImg = new ImageView(ghostAvatar)

  val hiss = new Media(getClass.getResource("/game.assets/ghost/hiss.mp3").toString)
  val hissPlayer = new MediaPlayer(hiss)
  val lose = new Media(getClass.getResource("/game.assets/ghost/lose.mp3").toString)
  val losePlayer = new MediaPlayer(lose)
  val youLose = new Image(getClass.getResourceAsStream("/game.assets/ghost/youLose.png"))
  val youLoseImg = new ImageView(youLose)
  youLoseImg.visible = false

  val jumpscare = new Media(getClass().getResource("/game.assets/ghost/jumpscare.mp3").toString)
  val jumpscarePlayer = new MediaPlayer(jumpscare)

  val auraSound = new Media(getClass().getResource("/game.assets/ghost/aura1.mp3").toString)
  val auraPlayer = new MediaPlayer(auraSound)


//  ghost generation function
  override def generate(num: Int): Set[coordinate] = {
    require(num <= gridHeight * gridWidth, "Number of coordinates must not exceed grid size")

    var ghostCoordinates = Set.empty[coordinate]
    var wallCoordinates = wallsSet

    while (ghostCoordinates.size < num) {
      val coord = (random.nextInt(gridWidth), random.nextInt(gridHeight))
      val minDistanceToPlayer = 5.0
      val minDistanceToGhosts = 4.0
      val minDistanceToWalls = 1.0


      val distanceToPlayer = distance(coord, (playerX, playerY))
      val distanceToGhosts = ghostCoordinates.forall(existingCoord => distance(coord, existingCoord) >= minDistanceToGhosts)
      val distanceToWalls = wallCoordinates.forall(wallCoord => distance(coord, wallCoord) >= minDistanceToWalls)

      if (distanceToPlayer >= minDistanceToPlayer && distanceToGhosts && distanceToWalls) {
        ghostCoordinates += coord
      }
    }

    ghostCoordinates
  }
//  Generates 3 x 3 aura for the ghosts
  def generateAura(thisSet: Set[coordinate]): Set[coordinate] = {

    // Maps surrounding coordiantes of each ghosts' (x, y)
    thisSet.flatMap { case (x, y) =>
      Set(
        (x + 1, y),
        (x + 1, y + 1),
        (x + 1, y - 1),
        (x, y - 1),
        (x, y + 1),
        (x - 1, y),
        (x - 1, y + 1),
        (x - 1, y - 1)
      )
    } filter { case (x, y) =>
      x >= 0 && x < gridWidth && y >= 0 && y < gridHeight && !(wallsSet.contains((x,y))) //filters any coordinates that exceeds grid size
    }
  }
}
