package game.assets.gameengine

import scala.util.Random

class Walls(playerX: Int, playerY : Int, gridWidth: Int, gridHeight: Int) extends EnvironmentObject(gridWidth : Int, gridHeight: Int) {
  var wallCoordinates = Set.empty[coordinate]

  override def generate(num: Int): Set[coordinate] = {

    while (wallCoordinates.size < num) {
      val length = 3 + Random.nextInt(3) // Random length between 3 and 5
      val orientation = Random.nextBoolean() // Random orientation (true for vertical, false for horizontal)
      val (x, y) = if (orientation) {
        (Random.nextInt(gridWidth), random.nextInt(gridHeight - length + 1))
      } else {
        (random.nextInt(gridWidth - length + 1), random.nextInt(gridHeight))
      }
      val newWallCoordinates = if (orientation) {
        (y until y + length).map(yCoord => (x, yCoord))
      } else {
        (x until x + length).map(xCoord => (xCoord, y))
      }
      val distanceToPlayer = newWallCoordinates.map(coord => distance(coord, (playerX, playerY))).min
      if (distanceToPlayer >= 3) {
        wallCoordinates ++= newWallCoordinates
      }
    }

    wallCoordinates
  }

}
