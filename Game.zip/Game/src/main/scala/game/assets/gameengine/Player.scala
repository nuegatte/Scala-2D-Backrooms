package game.assets.gameengine



import scalafx.scene.image.{Image, ImageView}
import scalafx.scene.media.{Media, MediaPlayer}


class Player(x : Int, y : Int, size: Int) {
  var X = x
  var Y = y

  val playerDefault = new Image(getClass.getResourceAsStream("/game.assets/playerSprite/playerDefault.png"))
  val playerUp = new Image(getClass.getResourceAsStream("/game.assets/playerSprite/playerUp.png"))
  val playerLeft = new Image(getClass.getResourceAsStream("/game.assets/playerSprite/playerLeft.png"))
  val playerRight = new Image(getClass.getResourceAsStream("/game.assets/playerSprite/playerRight.png"))
  val imageView = new ImageView(playerDefault)

  imageView.fitWidth = size
  imageView.fitHeight = size

  val footsteps = new Media(getClass().getResource("/game.assets/playerSprite/footstep.mp3").toString)
  val footstepPlayer = new MediaPlayer(footsteps)

  val collide = new Media(getClass().getResource("/game.assets/playerSprite/collide.mp3").toString)
  val collidePlayer = new MediaPlayer(collide)


}