package game.assets.gameengine

import scalafx.scene.control.Alert
import scalafx.scene.control.Alert.AlertType
import scalafx.stage.Stage

class CollisionDetection(ghosts: Set[(Int, Int)], ghostAura:  Set[(Int, Int)], wallsSet: Set[(Int, Int)],  gridWidth :Int, gridHeight : Int) {

  def isGhost(x: Int, y: Int): Boolean = {
    ghosts.contains((x, y))
  }

  def isAura(x: Int, y: Int): Boolean = {
    ghostAura.contains((x, y))
  }

  def isValidMove(x: Int, y: Int): Boolean = {
    x >= 0 && x < gridWidth && y >= 0 && y < gridHeight
  }

  def isCollision(x: Int, y: Int): Boolean = {
    (x >= 0 && x < gridWidth && y >= 0 && y < gridHeight) && (ghosts.contains((x, y)) || wallsSet.contains((x,y)))
  }

  def isWall(x: Int, y: Int): Boolean = {
    wallsSet.contains((x, y))
  }


}
